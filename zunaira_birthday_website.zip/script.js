let s=document.querySelectorAll('.slide'),i=0;
setInterval(()=>{s[i].classList.remove('active');i=(i+1)%s.length;s[i].classList.add('active');},3000);
function toggleMusic(){let m=document.getElementById('music');m.paused?m.play():m.pause();}
